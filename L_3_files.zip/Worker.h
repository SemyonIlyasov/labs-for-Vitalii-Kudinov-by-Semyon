#pragma once
#include <string>
#include <vector>
#include <fstream>
class Worker
{

public:
	virtual std::vector <std::string> do_work();
};

