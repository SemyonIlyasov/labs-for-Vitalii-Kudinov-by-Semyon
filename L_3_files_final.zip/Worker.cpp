#include "Worker.h"

std::vector <std::string> Worker::do_work() {
	std::vector <std::string> empty;
	return empty;
}
