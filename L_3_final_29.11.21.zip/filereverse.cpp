#include "filereverse.h"
#include <vector>
#include <string>
using namespace std;
filereverse::filereverse(vector <string> v, vector <string>* b) {
	this->arguments = v;
	this->b = b;
}

vector <string> filereverse::do_work() {
	if (arguments.size() != 0)
		throw exception("Wrong number of arguments");
	vector <string> res;
	vector <string> ::iterator i = (*b).begin();
	for (; i != (*b).end(); ++i) {
		string tmp = (*i);
		reverse(tmp.begin(), tmp.end());
		res.push_back(tmp);
	}
	*b = res;
	return res;
}