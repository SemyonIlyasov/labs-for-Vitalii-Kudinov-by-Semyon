#include "BotPlayer.h"
#include <iostream>
#include <random>
#include <vector>
BotPlayer::BotPlayer() {

}
int BotPlayer::make_move(int numlen) {
	std::vector <int> ints;
	unsigned int intslen = 10;
	for (int i = 0; i < 10; i++)
		ints.push_back(i);
	std::vector <int> number;
	std::random_device rd;
	std::mt19937 mersenne(rd());
	unsigned int i = 0;
	for (int i = 0; i < numlen - 1; i++)
	{
		unsigned int pred = (unsigned int)mersenne() % intslen;
		number.push_back(*(ints.begin() + pred));
		ints.erase(ints.begin() + pred);
		intslen--;
	}
	unsigned int pred = (unsigned int)mersenne() % intslen;
	if (*(ints.begin()) == 0) {
		ints.erase(ints.begin());
		intslen--;
		pred %= intslen;
	}
	number.push_back(*(ints.begin() + pred));
	ints.erase(ints.begin() + pred);
	unsigned int res = 0;
	unsigned int dec = 1;
	for (int i = 0; i < numlen; i++)
	{
		res += *(number.begin() + i) * dec;
		dec *= 10;
	}
	return res;
}