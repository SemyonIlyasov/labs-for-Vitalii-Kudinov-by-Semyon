#pragma once
#include "Player.h"
class BotPlayer :
    public Player
{
public:
    BotPlayer();
    int make_move(int numlen) override;
};

