#include "Controller.h"
#include <vector>
#include <iostream>
#include <map>
#include <random>
using namespace std;
Controller::Controller() {
};
void Controller::init_game() { // !!! - strings you should to correct if change
	vector <char> p;
	view.show_rules();
	//Initialization
	int a = 0, max_num_len = 0;
	cout << "Amount of players: \n";
	cin >> a;
	cout << "Max length of number: ([1,10])\n";
	cin >> max_num_len;
	int i = 0;
	while (i < a) {
		cout << "Choose who will play as player " << i + 1 << " (Human == H, Bot == B)\n";	// !!!
		char ch;
		cin >> ch;
		if (ch != 'H' && ch != 'B')															// !!!
			cout << "Oops! You wrote wrong symbol! Please try again.\n";
		else
			i++;
		p.push_back(ch);
	}
	this->amount_of_players = a;
	this->numlen = max_num_len;
	m.set_numlen(max_num_len);
	m.set_players(p);
	this->create_number(max_num_len);
	//END OF INIT
}

void Controller::create_number(int len) {
	vector <int> ints;
	unsigned int intslen = 10;
	for (int i = 0; i < 10; i++)
		ints.push_back(i);
	vector <int> number;
	random_device rd;
	mt19937 mersenne(rd());
	unsigned int i = 0;
	for (int i = 0; i < len; i++)
	{
		unsigned int pred = (unsigned int)mersenne() % intslen;
		number.push_back(*(ints.begin() + pred));
		ints.erase(ints.begin() + pred);
		intslen--;
	}
	this->number = number;
}


void Controller::game() {
	this->init_game();
	unsigned int* cows = new unsigned int, *bulls = new unsigned int;
	*cows = 1;
	*bulls = 1;
	int id = 0; 
	while (cows && bulls)
	{
		//do sth
		cout << id  + 1 << " Players turn!\n";
		unsigned int res = m.make_step(cows, bulls, id);
		unsigned int rescpy = res;
		int flag = parse_res(this->number, res, cows, bulls);
		if (flag == 0)
		{
			//continue
			view.show_step(res, id, *cows, *bulls);
		} 
		else if (flag == 1)
		{
			//show_win
			view.show_win(res, id);
		}
		else if (flag == 2)
		{
			// wrong number
			view.show_wrong_number_alert();
		} 
		else
		{
			//error
			throw exception("sth went wrong");
		}
		id = (id + 1) % this->amount_of_players;
	}
	
}

unsigned int Controller::make_step(
	unsigned int* cows, 
	unsigned int* bulls, 
	int id) {
	return m.make_step(cows, bulls, id);
}

unsigned int Controller::parse_res(std::vector <int> num, unsigned int res, unsigned int* cows, unsigned int* bulls) {
	if (res == 0)
		return 228; //err code
	else {
		// check unique numbers on res;
		// splite res to vector of ints;
		std::map <int, int> res_map;
		std::vector <int> res_vec;
		unsigned int rescpy = res;
		int err_flag = 1;
		while (rescpy > 0 && err_flag) {
			unsigned int rd = rescpy % 10;
			if (res_map[rd])
				err_flag = 0;
			else {
				res_map[rd] = 1;
				res_vec.push_back(rd);
			}
			rescpy /= 10;
		}
		if (err_flag == 0)
			return 2;	// wrong number
		unsigned int bulls_in_num = 0, cows_in_num = 0;
		std::vector <int>::iterator it1 = res_vec.begin();
		std::vector <int>::iterator it2 = this->number.begin();
		while (it1 != res_vec.end() && it2 != this->number.end()) {
			if (*it1 == *it2)
				bulls_in_num += 1;
			else if (res_map[*it2])
				cows_in_num += 1;
			it1++;
			it2++;
		}
		if (this->numlen == bulls_in_num)
			return 1;
		*cows = cows_in_num;
		*bulls = bulls_in_num;
		return 0;
	}
}