#pragma once
#include "ViewInterface.h"
#include "Model.h"
#include <vector>
class Controller
{
private:
	std::vector <int> number;
	unsigned int numlen;
	unsigned int amount_of_players;

	Model m;
	ViewInterface view;
	void init_game();
	void create_number(int len);
	unsigned int parse_res(std::vector<int> num, unsigned int res, unsigned int*cows, unsigned int*bulls);
	unsigned int make_step(unsigned int *cows, unsigned int* bulls, int id);
public:
	Controller();
	void game();
};

