#include "HumanPlayer.h"
#include <iostream>
HumanPlayer::HumanPlayer() {

}
int HumanPlayer::make_move(int numlen) {
	unsigned int res = 0;
	while (1) {
		std::cout << " print your number here ... ";
		std::cin >> res;
		unsigned int rescpy = res;
		unsigned int reslen = 0;
		for (; rescpy > 0; rescpy /= 10)
			reslen += 1;
		if (reslen != numlen)
			std::cout << "Number is not correct! Please, try again. :(\n";
		else
			break;
	}
	return res;
}