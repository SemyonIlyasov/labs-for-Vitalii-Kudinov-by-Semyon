#pragma once
#include "Player.h"
class HumanPlayer :
    public Player
{
public:
    HumanPlayer();
    int make_move(int numlen);
};

