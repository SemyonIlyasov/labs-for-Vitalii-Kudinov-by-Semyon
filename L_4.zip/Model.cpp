#include "Model.h"
#include "Player.h"
#include "HumanPlayer.h"
#include "BotPlayer.h"
using namespace std;
Model::Model() {
}

void Model::set_numlen(unsigned int k) {
	numlen = k;
}

void Model::set_players(std::vector <char> v) {
	std::vector <char> ::iterator it = v.begin();
	for (; it != v.end(); it++)
		if (*it == 'H') this->players.push_back(new HumanPlayer);
		else if (*it == 'B') this->players.push_back(new BotPlayer);
		// else !!! 
}

int Model::make_step(unsigned int* cows, unsigned int* bulls, int id) { 
	unsigned int res = (*this->players[id]).make_move(this->numlen);
	return res;
}