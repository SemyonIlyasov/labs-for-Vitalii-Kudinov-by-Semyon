#include "Player.h"

int Player::make_move(int numlen) {
	return 0;
}