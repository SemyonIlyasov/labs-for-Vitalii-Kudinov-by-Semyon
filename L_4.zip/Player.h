#pragma once
class Player
{
public:
	virtual int make_move(int numlen);
};

