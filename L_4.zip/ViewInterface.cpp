#include "ViewInterface.h"
#include <iostream>
ViewInterface::ViewInterface() {

};

void ViewInterface::show_step(unsigned int res, int id, unsigned int cows, unsigned int bulls) {
	std:: cout << "Player " << id  + 1<< " try " << res << ".\n";
	std:: cout << "It has " << cows << " cows, " << bulls << " bulls.\n";
}

void ViewInterface::show_win(unsigned int res, int id) {
	std::cout << "Player " << id + 1 << " WON!!! " << " Number == " << res << ".\n";
	//std::cout << "It has " << cows << " cows, " << bulls << " bulls.\n";
	exit(0);
}

void ViewInterface::show_wrong_number_alert() {
	std::cout << "Wrong number was detected!\n";
	std::cout << "This players turn ended, try better next time. :'(\n";
}

void ViewInterface::show_rules() {
	std::cout << "                        Welcome to /Bulls and cows\\ game!\n";
	std::cout << "        Rules:\n";
	std::cout << "            1. This game can play more than 2 players(but not less than 1 :) )\n";
	std::cout << "            2. Discuss with other players length of number and put it below ([1,10])\n";
	std::cout << "            3. Digits in hidden number doesn't repeat.\n";
	std::cout << "            4. After the beginning of the game players will make his moves\n";
	std::cout << "               every player will try his number, number should not contain similar digits\n";
	std::cout << "               after player's turn will be shown amount of cows and bulls in his number.\n";
	std::cout << "                       Cow - right number on the wrong position\n";
	std::cout << "                       Bull - right number on the right position\n";
	std::cout << "            5. First player who guess the number wins!\n";
	std::cout << "                                     Good luck!\n";
}