#include "Controller.h"
int main(int args, char** argv) {

	Controller controller = Controller();
	controller.game();
	return 0;
}