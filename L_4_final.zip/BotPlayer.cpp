#include "BotPlayer.h"
#include <iostream>
#include <random>
BotPlayer::BotPlayer() {

}
unsigned int BotPlayer::make_move(int numlen, std::set <unsigned int> all_results) {
	int flag = 0;
	unsigned int res;
	while (flag == 0) {
		res = 0;
		std::vector <int> number;
		std::random_device rd;
		std::mt19937 mersenne(rd());
		for (int i = 0; i < numlen - 1; i++)
			number.push_back((unsigned int)mersenne() % 10);
		number.push_back((unsigned int)mersenne() % 9 + 1);
		unsigned int dec = 1;
		for (int i = 0; i < numlen; i++)
		{
			res += *(number.begin() + i) * dec;
			dec *= 10;
		}

  		if (all_results.find(res) == all_results.end())
			break;
	}
 	return res;
}