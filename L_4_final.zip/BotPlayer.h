#pragma once
#include "Player.h"
class BotPlayer :
    public Player
{
public:
    BotPlayer();
    unsigned int make_move(int numlen, std::set <unsigned int> all_results) override;
};

