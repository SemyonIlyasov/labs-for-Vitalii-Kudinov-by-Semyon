#include "Controller.h"
#include <vector>
#include <iostream>
#include <map>
#include <random>
using namespace std;

Controller::Controller() {
};
void Controller::init_game() { // !!! - strings you should to correct if change
	vector <char> p;
	view.show_rules();
	
	//Initialization
	int a = 0, max_num_len = 0;
	cout << "Amount of players: \n";
	cin >> a;
	cout << "Max length of number: ([1,10])\n";
	cin >> max_num_len;
	int i = 0;
	while (i < a) {
		cout << "Choose who will play as player " << i + 1 << " (Human == H, Bot == B)\n";	// !!!
		char ch;
		cin >> ch;
		if (ch != 'H' && ch != 'B')															// !!!
			cout << "Oops! You wrote wrong symbol! Please try again.\n";
		else
			i++;
		p.push_back(ch);
	}
	this->amount_of_players = a;
	this->numlen = max_num_len;
	m.set_numlen(max_num_len);
	m.set_players(p);
	this->create_number(max_num_len);
	//vector <int> ::iterator it = this->number.begin();
	//for (; it != this->number.end(); it++)
	//	cout << *it;
	//END OF INIT
}

void Controller::create_number(int len) {
	random_device rd;
	mt19937 mersenne(rd());
	for (int i = 0; i < len - 1; i++)
		this->number.push_back((unsigned int)mersenne() % 10);
	this->number.push_back((unsigned int)mersenne() % 9 + 1);
}


void Controller::game() {
	this->init_game();
	unsigned int* cows = new unsigned int, *bulls = new unsigned int;
	*cows = 1;
	*bulls = 1;
	int id = 0; 
	while (cows && bulls)
	{
		//do sth
		view.show_table(this->gamefield_info);
		cout << id  + 1 << " Players turn!\n";
		unsigned int res = m.make_step(id, this->all_results);
		unsigned int rescpy = res;
		int flag = parse_res(this->number, res, cows, bulls);
		if (flag == 0)
		{
			node b;
			b.playerID = id;
			b.players_number = res;
			b.bulls = *bulls;
			b.cows = *cows;
			this->gamefield_info.push_back(b);
			this->all_results.insert(res);
		}
		else if (flag == 1)
		{
			//show_win
			view.show_win(res, id);
		}
		else if (flag == 2)
		{
			// wrong number
			view.show_wrong_number_alert();
		} 
		else
		{
			//error
			throw exception("sth went wrong");
		}
		id = (id + 1) % this->amount_of_players;
	}
	
}

unsigned int Controller::parse_res(std::vector <int> num, unsigned int res, unsigned int* cows, unsigned int* bulls) {
	if (res == 0)
		return 228; //err code
	else {
		std::map <int, int> res_map;
		std::vector <int> res_vec;
		unsigned int rescpy = res;
		while (rescpy > 0) {
			unsigned int rd = rescpy % 10;
			res_map[rd] += 1;
			res_vec.push_back(rd);
			rescpy /= 10;
		}
		unsigned int bulls_in_num = 0, cows_in_num = 0;
		std::vector <int>::iterator it1 = res_vec.begin();
		std::vector <int>::iterator it2 = this->number.begin();
		while (it1 != res_vec.end() && it2 != this->number.end()) {
			if (*it1 == *it2) {
				bulls_in_num += 1;
				res_map[*it1] -= 1;
			}
			else if (res_map[*it2]) {
				cows_in_num += 1;
				res_map[*it2] -= 1;
			}
			it1++;
			it2++;
		}
		if (this->numlen == bulls_in_num)
			return 1;
		*cows = cows_in_num;
		*bulls = bulls_in_num;
		return 0;
	}
}