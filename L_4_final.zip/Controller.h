#pragma once
#include "ViewInterface.h"
#include "Model.h"
#include <vector>
#include <set>
class Controller
{
private:
	std::vector <int> number;
	unsigned int numlen;
	unsigned int amount_of_players;
	std::vector <node> gamefield_info;
	std::set <unsigned int> all_results;
	Model m;
	ViewInterface view;
	void init_game();
	void create_number(int len);
	unsigned int parse_res(std::vector<int> num, unsigned int res, unsigned int*cows, unsigned int*bulls);
public:
	Controller();
	void game();
};

