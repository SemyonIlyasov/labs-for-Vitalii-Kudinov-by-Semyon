#pragma once
#include "Player.h"
class HumanPlayer :
    public Player
{
public:
    HumanPlayer();
    unsigned int make_move(int numlen, std::set <unsigned int> all_results);
};

