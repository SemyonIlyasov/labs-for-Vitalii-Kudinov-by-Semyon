#include "Model.h"
#include "Player.h"
#include "HumanPlayer.h"
#include "BotPlayer.h"
using namespace std;
Model::Model() {
}

void Model::set_numlen(unsigned int k) {
	numlen = k;
}

void Model::set_players(std::vector <char> v) {
	std::vector <char> ::iterator it = v.begin();
	for (; it != v.end(); it++)
		if (*it == 'H') this->players.push_back(new HumanPlayer);
		else if (*it == 'B') this->players.push_back(new BotPlayer);
		// else !!! 
}

int Model::make_step(int id, std::set <unsigned int> all_results) {
	unsigned int res = (*this->players[id]).make_move(this->numlen, all_results);
	return res;
}