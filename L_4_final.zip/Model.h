#pragma once
#include <vector>
#include "Player.h"
class Model
{
private:
	int numlen;
	std::vector <Player*> players;
	std::vector <std::vector <unsigned int>> players_moves;
public:
	Model();
	void set_numlen(unsigned int k);
	void set_players(std::vector <char> v);
	int make_step(int id, std::set <unsigned int> all_results);
};

