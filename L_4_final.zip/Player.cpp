#include "Player.h"

unsigned int Player::make_move(int numlen, std::set <unsigned int> all_results) {
	return 0;
}