#pragma once
#include <vector>
#include <set>
class Player
{
public:
	virtual unsigned int make_move(int numlen, std::set <unsigned int> all_results);
};

