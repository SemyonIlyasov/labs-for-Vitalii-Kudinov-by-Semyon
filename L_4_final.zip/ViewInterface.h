#pragma once
#include <vector>

typedef struct node
{
	unsigned int playerID;
	unsigned int players_number;
	unsigned int cows;
	unsigned int bulls;
}node;

class ViewInterface
{
public:
	ViewInterface();
	void show_win(unsigned int res, int id);
	void show_rules();
	void show_wrong_number_alert();
	void show_step(unsigned int res, int id, unsigned int cows, unsigned int bulls);
	//void show_cows_and_bulls(int player, int cows, int bulls);
	//void show_players_moves(std::vector <unsigned int> v);
	void show_table(std::vector <node> gamefield);
};

